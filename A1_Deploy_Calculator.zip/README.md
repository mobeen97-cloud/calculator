# Simple Calculator

A static calculator (add, subtract, multiply, divide) built with plain HTML, CSS and JavaScript. There is no build step and no dependencies, so it can be hosted anywhere that serves static files.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Page markup |
| `style.css` | Styles (light and dark theme) |
| `script.js` | Calculator logic and keyboard support |
| `netlify.toml` | Netlify settings |
| `vercel.json` | Vercel settings |
| `.github/workflows/pages.yml` | Auto-deploy to GitHub Pages |

## Run locally

Double-click `index.html`, or from this folder run:

```
python -m http.server 8000
```

Then open http://localhost:8000

## Deploy online (pick one)

### Option 1: Netlify Drop (fastest, no account setup needed to try)
1. Go to https://app.netlify.com/drop
2. Drag the `A1_Deploy_Calculator` folder onto the page.
3. Netlify gives you a public URL.

### Option 2: GitHub Pages
1. Create a new GitHub repository and push this folder to the `main` branch:
   ```
   cd D:\A1_Deploy_Calculator
   git init
   git add .
   git commit -m "Add calculator"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. In the repo, open Settings > Pages and set Source to **GitHub Actions**.
3. The included workflow deploys on every push. The site will be at `https://<your-username>.github.io/<repo-name>/`.

### Option 3: Vercel
1. Install the CLI: `npm i -g vercel`
2. From this folder run `vercel` and accept the defaults. Use `vercel --prod` for the production URL.

### Option 4: Cloudflare Pages
1. In the Cloudflare dashboard open Workers & Pages > Create > Pages.
2. Upload this folder (direct upload) or connect your GitHub repo.
3. Leave the build command empty and set the output directory to `/`.
